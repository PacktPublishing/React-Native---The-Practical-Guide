import React from 'react';
import { Text, View } from 'react-native';

export default function App() {
  return (
    <View>
      <Text>A new app!</Text>
    </View>
  );
}
