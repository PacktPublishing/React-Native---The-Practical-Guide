import React from 'react';

import PlacesNavigator from './navigation/PlacesNavigator';

export default function App() {
  return <PlacesNavigator />;
}
