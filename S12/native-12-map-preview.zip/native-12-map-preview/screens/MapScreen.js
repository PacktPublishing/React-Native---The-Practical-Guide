import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const MapScreen = props => {
  return (
    <View>
      <Text>MapScreen</Text>
    </View>
  );
};

const styles = StyleSheet.create({});

export default MapScreen;
