class Place {
    constructor(id, title) {
        this.id = id;
        this.title = title;
    }
}

export default Place;