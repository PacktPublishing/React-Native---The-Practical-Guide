import React from 'react';

const App = () => {
  return <h1 title="This works!">Hi, <span>this</span> is ReactJS!</h1>;
};

export default App;
